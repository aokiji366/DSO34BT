﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lapeng
{
    public partial class Registerproperty : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            GridView1.DataBind();
        }
        //Add button click
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (checkIfAddressExists())
            {
                Response.Write("<script>alert(' House address already exists, try updating');</script>");
            }
            else
            {
                Add();
            }
        }

        //Update button click
        protected void Button3_Click(object sender, EventArgs e)
        {
                 if (checkIfAddressExists())
            {
                 updateRoom();
            }
            else
            {
             
                      Response.Write("<script>alert(' User name does not exist');</script>");
            }
        }


        //Delete button
            protected void Button4_Click(object sender, EventArgs e)
            {
                if (checkIfAddressExists())
                {
                    deleteRoom();
                }
                else
                {

                    Response.Write("<script>alert(' Update succsesful');</script>");
                    
                }
            }
       
            //user defined function
        //Delete room
        void deleteRoom()
            {
                try
                {
                    SqlConnection con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();

                    }

                    SqlCommand cmd = new SqlCommand("DELETE from room_details_tbl WHERE user_id='" + TextBox1.Text.Trim() + "' AND address='"+TextBox3.Text.Trim()+"'" , con);
                   
                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Room Deleted');</script>");
                    GridView1.DataBind();
                    clearForm();

                }

                catch (Exception ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
            //check if address exists
            bool checkIfAddressExists()
            {
                try
                {
                    SqlConnection con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();

                    }

                    SqlCommand cmd = new SqlCommand("SELECT * FROM room_details_tbl WHERE address='" + TextBox3.Text.Trim() + "';", con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    da.Fill(dt);

                    if (dt.Rows.Count >= 1)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                }

                catch (Exception ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                    return false;
                }

            }
            //add
            void Add()
            {
                try
                {
                    string filepath = "~/examples/room.jpeg";
                    string filename = Path.GetFileName(FileUpload1.PostedFile.FileName);
                    FileUpload1.SaveAs(Server.MapPath("examples/" + filename));
                    filepath = "~/examples/" + filename;


                    SqlConnection con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();

                    }

                    SqlCommand cmd = new SqlCommand("INSERT INTO room_details_tbl(user_id,address,contact_no,description,price,benefits,room_img_link) VALUES (@user_id,@address,@contact_no,@description,@price,@benefits,@room_img_link)", con);
                    cmd.Parameters.AddWithValue("@user_id", TextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@address", TextBox3.Text.Trim());
                    cmd.Parameters.AddWithValue("@contact_no", TextBox5.Text.Trim());
                    cmd.Parameters.AddWithValue("@description", DropDownList1.SelectedItem.Value);
                    cmd.Parameters.AddWithValue("@price", TextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@benefits", TextBox4.Text.Trim());
                    cmd.Parameters.AddWithValue("@room_img_link", filepath);

                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Property added');</script>");
                    GridView1.DataBind();
                    clearForm();

                }

                catch (Exception ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }

            //update
            void updateRoom()
            {
                try
                {
                    SqlConnection con = new SqlConnection(strcon);
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();

                    }

                    SqlCommand cmd = new SqlCommand("UPDATE room_details_tbl SET contact_no=@contact_no,description=@description,price=@price,benefits=@benefits WHERE user_id='" + TextBox1.Text.Trim() + "' ", con);
                    cmd.Parameters.AddWithValue("@user_id", TextBox1.Text.Trim());
                    cmd.Parameters.AddWithValue("@address", TextBox3.Text.Trim());
                    cmd.Parameters.AddWithValue("@contact_no", TextBox5.Text.Trim());
                    cmd.Parameters.AddWithValue("@description", DropDownList1.SelectedItem.Value);
                    cmd.Parameters.AddWithValue("@price", TextBox2.Text.Trim());
                    cmd.Parameters.AddWithValue("@benefits", TextBox4.Text.Trim());

                    cmd.ExecuteNonQuery();
                    con.Close();
                    Response.Write("<script>alert('Property updated');</script>");
                    GridView1.DataBind();
                        clearForm();


                }


                catch (Exception ex)
                {
                    Response.Write("<script>alert('" + ex.Message + "');</script>");
                }
            }
        //Clear form
        void clearForm()
            {
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
                TextBox5.Text = "";
           
            }

       
        }
        

}


    
