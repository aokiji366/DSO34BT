﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lapeng
{
    public partial class Site1 : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (Session["role"].Equals(""))
                {
                    LinkButton1.Visible = true; //user login link buton
                    LinkButton2.Visible = true; //user singup link buton
                    LinkButton4.Visible = true;//View Property


                    LinkButton3.Visible = false; //logout link buton
                    LinkButton7.Visible = false; //Hello user  link buton
                    LinkButton3.Visible = false; //logout link buton
                    LinkButton6.Visible = false; //register property link buton
                    LinkButton11.Visible = false; //Update propertry link buton
                    LinkButton10.Visible = false; //update profile link buton
                }
                else if(Session["role"].Equals("user"))
                {

                    LinkButton4.Visible = false;//View Property
                    LinkButton3.Visible = true; //logout link buton
                    LinkButton7.Visible = true; //Hello user  link buton
                    LinkButton7.Text = "Hello " + Session["userID"].ToString();
                    LinkButton3.Visible = true; //logout link buton
                    LinkButton6.Visible = true; //register property link buton
                    LinkButton11.Visible = true; //Update propertry link buton
                    LinkButton10.Visible = true; //update profile link buton

                    LinkButton1.Visible = false; //user login link buton
                    LinkButton2.Visible = false; //user singup link buton
                }

            }
           catch(Exception ex)
            {
                //Response.Write("<script>alert('" + ex.Message + "');</script>");
            } 
        }
        // log in button
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("userlogin.aspx");
        }
        // View property button
        protected void LinkButton4_Click(object sender, EventArgs e)
        {
            Response.Redirect("viewproperties.aspx");
        }
        //User sing up button
        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("usersingup.aspx");
        }

        // log out button
        protected void LinkButton3_Click(object sender, EventArgs e)
        {
            Session["userid"] ="";
            Session["name"] ="";
            Session["role"] = "";

            LinkButton1.Visible = true; //user login link buton
            LinkButton2.Visible = true; //user singup link buton
            LinkButton4.Visible = true;//View Property


            LinkButton3.Visible = false; //logout link buton
            LinkButton7.Visible = false; //Hello user  link buton
            LinkButton3.Visible = false; //logout link buton
            LinkButton6.Visible = false; //register property link buton
            LinkButton11.Visible = false; //Update propertry link buton
            LinkButton10.Visible = false; //update profile link buton
            Response.Redirect("homepage.aspx");
        }

        //Hello user
        protected void LinkButton7_Click(object sender, EventArgs e)
        {

        }
        //register property button
        protected void LinkButton6_Click(object sender, EventArgs e)
        { 
            Response.Redirect("registerproperty.aspx");
        }
        //Update user property button
        protected void LinkButton11_Click(object sender, EventArgs e)
        {
           Response.Redirect("registerproperty.aspx");
        }

        protected void LinkButton10_Click(object sender, EventArgs e)
        {
            Response.Redirect("userprofile.aspx");
        }

       

    
       
    }
}