﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lapeng
{
    public partial class userprofile : System.Web.UI.Page
    {
        string strcon = ConfigurationManager.ConnectionStrings["con"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            if (checkIdExists() & checkPassword())
            {
                updateUser();
            }
            else
            {
                Response.Write("<script>alert(' ID number doesnt exist');</script>");
            }
        }
        //Button Go
        protected void Button2_Click(object sender, EventArgs e)
        {
            
                populate();
           
        }


        //user defined functions

        // check if id exists
        bool checkIdExists()
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("SELECT * FROM property_owner_tbl WHERE id_no='" + TextBox2.Text.Trim() + "';", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);

                if (dt.Rows.Count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                return false;
            }

        }

        //Update user info
        void updateUser()
        {
            if(TextBox6.Text.Trim().Equals(""))
            {
                Response.Write("<script>alert('User Id cannot be blank');</script>");
            }
            else
            {
                 try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("UPDATE property_owner_tbl SET email=@email,contact_no=@contact_no,user_id=@user_id,password=@password WHERE id_no='" + TextBox2.Text.Trim() + "' ", con);
                cmd.Parameters.AddWithValue("@email", TextBox4.Text.Trim());
                cmd.Parameters.AddWithValue("@contact_no", TextBox5.Text.Trim());
                cmd.Parameters.AddWithValue("@user_id", TextBox6.Text.Trim());
                cmd.Parameters.AddWithValue("@password", TextBox8.Text.Trim());
               

                cmd.ExecuteNonQuery();
                con.Close();
                Response.Write("<script>alert('Profile updated');</script>");
                GridView1.DataBind();
                clearForm();


            }


            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            }
           
        }

        //clear form
        void clearForm()
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            TextBox5.Text = "";
            TextBox6.Text = "";
            TextBox7.Text = "";
            TextBox8.Text = "";
        }
        // check password
        bool checkPassword()
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("SELECT * FROM property_owner_tbl WHERE password='" + TextBox7.Text.Trim() + "';", con);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();

                da.Fill(dt);

                if (dt.Rows.Count >= 1)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
                return false;
            }
        }

       void populate()
        {
            try
            {
                SqlConnection con = new SqlConnection(strcon);
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();

                }

                SqlCommand cmd = new SqlCommand("SELECT * FROM property_owner_tbl  WHERE id_no='" + TextBox2.Text.Trim() + "' ", con);
               TextBox1.Text="";
               SqlDataReader dr = cmd.ExecuteReader();
               if (dr.HasRows)
               {
                   while (dr.Read())
                   {
                       TextBox1.Text = dr.GetValue(0).ToString();
                       TextBox3.Text = dr.GetValue(1).ToString();
                       TextBox4.Text = dr.GetValue(3).ToString();
                       TextBox5.Text = dr.GetValue(4).ToString();
                       DropDownList1.Text = dr.GetValue(5).ToString();
                       TextBox6.Text = dr.GetValue(6).ToString();
                       TextBox7.Text = dr.GetValue(7).ToString();
                   }

                   

               }

               else
               {
                   Response.Write("<script>alert('Invalid credentials');</script>");
               }

                


            }


            catch (Exception ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

       
        
        

        
    }
}